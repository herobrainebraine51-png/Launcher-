package com.ninja.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var dark = false
    private lateinit var root: LinearLayout
    private lateinit var appGrid: GridLayout
    private lateinit var search: EditText
    private lateinit var drawer: LinearLayout
    private var allApps: List<android.content.pm.ResolveInfo> = emptyList()
    private var drawerVisible = false

    private val bg: Int get() = if (dark) Color.rgb(15, 18, 29) else Color.rgb(242, 245, 252)
    private val panel: Int get() = if (dark) Color.argb(150, 38, 45, 65) else Color.argb(175, 255, 255, 255)
    private val fg: Int get() = if (dark) Color.rgb(245, 247, 255) else Color.rgb(28, 35, 54)
    private val muted: Int get() = if (dark) Color.rgb(165, 174, 196) else Color.rgb(105, 115, 137)
    private val accent: Int get() = Color.rgb(116, 139, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemMode()
        loadApps()
        buildHome()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val wasDark = dark
        applySystemMode()
        if (wasDark != dark) buildHome()
        else buildHome()
    }

    private fun applySystemMode() {
        dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            window.decorView.systemUiVisibility =
                if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 24, stroke: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }
    }

    private fun text(value: String, size: Float, color: Int = fg, bold: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
    }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(14))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                if (dark) intArrayOf(Color.rgb(17, 22, 39), Color.rgb(35, 40, 68), Color.rgb(15, 18, 29))
                else intArrayOf(Color.rgb(228, 237, 255), Color.rgb(246, 241, 255), Color.rgb(239, 246, 255))
            )
        }
        setContentView(root)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(text("NINJA", 17f, fg, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        top.addView(text(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date()), 13f, muted))
        root.addView(top)

        val clock = text(SimpleDateFormat("h:mm", Locale.getDefault()).format(Date()), 54f, fg, true)
        clock.setPadding(0, dp(28), 0, 0)
        root.addView(clock)
        val greeting = text("Your space. Your style.", 15f, muted)
        root.addView(greeting)

        val searchBar = EditText(this).apply {
            hint = "Search apps"
            textSize = 15f
            setSingleLine(true)
            setTextColor(fg)
            setHintTextColor(muted)
            background = rounded(panel, 22, if (dark) 0x337F91FF else 0x44748BFF)
            setPadding(dp(18), 0, dp(18), 0)
            compoundDrawablePadding = dp(8)
        }
        search = searchBar
        val searchParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(24) }
        root.addView(searchBar, searchParams)
        searchBar.setOnEditorActionListener { _, _, _ ->
            showDrawer(searchBar.text.toString())
            true
        }

        val section = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(24), 0, dp(12))
        }
        section.addView(text("Favorites", 17f, fg, true), LinearLayout.LayoutParams(0, dp(30), 1f))
        val all = text("All apps  ›", 13f, accent, true)
        all.setOnClickListener { showDrawer("") }
        section.addView(all)
        root.addView(section)

        val scroll = ScrollView(this).apply { clipToPadding = false }
        appGrid = GridLayout(this).apply {
            columnCount = adaptiveColumns()
            useDefaultMargins = false
        }
        scroll.addView(appGrid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        populateFavorites()

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(panel, 28, if (dark) 0x337F91FF else 0x33748BFF)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val dockText = text("  ◉      Apps      •      Settings  ", 14f, fg, true)
        dockText.gravity = Gravity.CENTER
        dockText.setOnClickListener { showDrawer("") }
        dock.addView(dockText, LinearLayout.LayoutParams(-1, dp(44)))
        val dockParams = LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(12) }
        root.addView(dock, dockParams)
    }

    private fun adaptiveColumns(): Int {
        val widthDp = resources.configuration.screenWidthDp
        return when {
            widthDp >= 900 -> 7
            widthDp >= 600 -> 6
            widthDp >= 420 -> 5
            widthDp >= 360 -> 4
            else -> 3
        }
    }

    private fun populateFavorites() {
        appGrid.removeAllViews()
        val count = minOf(allApps.size, adaptiveColumns() * 2)
        for (i in 0 until count) appGrid.addView(createAppTile(allApps[i], appGrid.columnCount))
    }

    private fun createAppTile(info: android.content.pm.ResolveInfo, columns: Int): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(10), dp(4), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                if (launch != null) startActivity(launch)
            }
        }
        val iconFrame = FrameLayout(this).apply {
            background = rounded(if (dark) 0x553F4B70 else 0x99FFFFFF, 20, if (dark) 0x447F91FF else 0x55748BFF)
            elevation = dp(3).toFloat()
        }
        val icon = ImageView(this).apply {
            setImageDrawable(info.loadIcon(packageManager))
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(13), dp(13), dp(13), dp(13))
        }
        iconFrame.addView(icon, FrameLayout.LayoutParams(-1, -1))
        tile.addView(iconFrame, LinearLayout.LayoutParams(dp(58), dp(58)))
        val label = text(info.loadLabel(packageManager).toString(), 11f, fg)
        label.gravity = Gravity.CENTER
        label.maxLines = 1
        label.ellipsize = android.text.TextUtils.TruncateAt.END
        val lp = LinearLayout.LayoutParams(-1, dp(24)).apply { topMargin = dp(5) }
        tile.addView(label, lp)
        val width = (resources.displayMetrics.widthPixels - dp(44)) / columns
        return tile.apply { layoutParams = ViewGroup.LayoutParams(width, dp(102)) }
    }

    private fun showDrawer(query: String) {
        if (drawerVisible) {
            root.removeView(drawer)
            drawerVisible = false
        }
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(bg, 26, if (dark) 0x557F91FF else 0x55748BFF)
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        heading.addView(text("All applications", 20f, fg, true), LinearLayout.LayoutParams(0, dp(42), 1f))
        val close = text("✕", 20f, muted, true)
        close.gravity = Gravity.CENTER
        close.setOnClickListener { root.removeView(drawer); drawerVisible = false }
        heading.addView(close, LinearLayout.LayoutParams(dp(42), dp(42)))
        drawer.addView(heading)

        val filter = EditText(this).apply {
            hint = "Find an app"
            setSingleLine(true)
            setTextColor(fg)
            setHintTextColor(muted)
            background = rounded(panel, 18)
            setPadding(dp(14), 0, dp(14), 0)
            setText(query)
        }
        drawer.addView(filter, LinearLayout.LayoutParams(-1, dp(48)))
        val listScroll = ScrollView(this)
        val list = GridLayout(this).apply { columnCount = adaptiveColumns() }
        listScroll.addView(list)
        drawer.addView(listScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(drawer, LinearLayout.LayoutParams(-1, 0, 1f))
        drawerVisible = true

        fun render(q: String) {
            list.removeAllViews()
            val matches = allApps.filter {
                it.loadLabel(packageManager).toString().contains(q, true)
            }
            matches.forEach { list.addView(createAppTile(it, list.columnCount)) }
        }
        render(query)
        filter.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
    }
}
