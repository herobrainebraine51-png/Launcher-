plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.ninja.launcher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ninja.launcher"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "2.0"
    }
}
