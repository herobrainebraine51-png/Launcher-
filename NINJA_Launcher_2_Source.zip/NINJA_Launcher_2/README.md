# NINJA Launcher 2.0

Native Android home launcher built with Kotlin.

- System light/dark mode
- Responsive phone/tablet layout
- Adaptive app grid and app search
- Android HOME intent support
- Minimum Android 6.0 (API 23), target Android 15 (API 35)

Build with `gradle assembleDebug` using JDK 17 and Android SDK 35.
